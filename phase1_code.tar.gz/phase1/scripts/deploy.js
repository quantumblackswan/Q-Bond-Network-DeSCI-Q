const hre = require("hardhat");

/**
 * Deploys the Phase 1 core contracts:
 *  - QIEToken (soul‑bound ERC‑721)
 *  - ValidatorRegistry (non‑transferable validator NFT)
 *  - XPYield (staking engine for XP accrual)
 *  - BondEscrow (bond escrow contract coordinating staking and lockup)
 *
 * The script expects the following environment variables to be defined:
 *  - STAKING_TOKEN: Address of the ERC20 token used for staking (QBOND)
 *  - REWARD_RATE:   Reward rate in XP per second per token, scaled by 1e18
 *
 * The deployment process logs each contract address for later reference. It
 * uses Hardhat's `waitForDeployment` to ensure that the transaction is
 * mined before proceeding【172224971729504†L319-L353】.
 */
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying contracts with account:", deployer.address);

  // Deploy the QIE soul‑bound token
  const QIEFactory = await hre.ethers.getContractFactory("QIEToken");
  const qie = await QIEFactory.deploy();
  await qie.waitForDeployment();
  console.log("QIEToken deployed to:", await qie.getAddress());

  // Deploy the Validator Registry
  const ValidatorFactory = await hre.ethers.getContractFactory("ValidatorRegistry");
  const validator = await ValidatorFactory.deploy();
  await validator.waitForDeployment();
  console.log("ValidatorRegistry deployed to:", await validator.getAddress());

  // Retrieve staking token address and reward rate from environment variables
  const stakingTokenAddress = process.env.STAKING_TOKEN;
  const rewardRate = process.env.REWARD_RATE;
  if (!stakingTokenAddress || !rewardRate) {
    throw new Error("Please define STAKING_TOKEN and REWARD_RATE in the environment");
  }

  // Deploy the XPYield engine
  const XPYieldFactory = await hre.ethers.getContractFactory("XPYield");
  const xpYield = await XPYieldFactory.deploy(stakingTokenAddress, rewardRate);
  await xpYield.waitForDeployment();
  console.log("XPYield deployed to:", await xpYield.getAddress());

  // Deploy the BondEscrow contract referencing the staking token and XPYield engine
  const BondEscrowFactory = await hre.ethers.getContractFactory("BondEscrow");
  const escrow = await BondEscrowFactory.deploy(stakingTokenAddress, await xpYield.getAddress());
  await escrow.waitForDeployment();
  console.log("BondEscrow deployed to:", await escrow.getAddress());
}

main()
  .then(() => console.log("Phase 1 contracts deployed successfully"))
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  });
